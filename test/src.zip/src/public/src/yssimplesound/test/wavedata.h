#ifndef WAVDATA_IS_INCLUDED
#define WAVDATA_IS_INCLUDED
/* { */
extern const unsigned long long sizeof_WaveData;
extern const unsigned char WaveData[];
/* } */
#endif
